package dungeon;
/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */

/**
 *
 * @author Denny
 */
public class Armor {
    
    int lightArmor = 11;
    int mediumArmor = 13;
    int heavyArmor = 18;
    
}
