/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package dungeon;
import java.util.Scanner;
import java.io.Reader;
import java.io.*;
/**
 *
 * @author Josh
 */
public class TileManager {
    int numOfE;
    Scanner s = new Scanner(System.in);
    char[][] Map;
    String[] strMap;
    String FinMap;
    int playerX;
    int playerY;
    public TileManager(){
        Map = new char[18][65];
        strMap = new String[18];
        FinMap = null;
        playerX = 1;
        playerY = 16;
        numOfE = 0;
    }
    public void charToStr(){
        FinMap = null;
        char[] tempMap = new char[65];
        for(int x = 0; x < 18; x++){
            for(int y = 0; y < 65; y++){
                tempMap[y] = Map[x][y];
                strMap[x] = new String(tempMap);
            }
        }
        for(int z = 0; z < 18; z++){
            if(FinMap == null){
                FinMap = strMap[z];
            }
            else{
                FinMap = FinMap +"\n"+ strMap[z];
            }
        }
    }
    public String getMap(){
        return FinMap;
    }
    public void MapProcess(){
        readMap();
        charToStr();
        
    }
    public String updateMap(){
        charToStr();
        String str = getMap();
        return str;
    }
    
    public int Enemies(){
        int num = 0;
        for(int x = 0; x < 18; x++){
            for(int y = 0; y < 65; y++){
                if(Map[x][y] != '0' && Map[x][y] != '@' && Map[x][y] != '.'){
                    num++;
                }
            }
        }
        
        return num;
    }
    
    
    public void updateBox(){
        String conMap = new String();
    }
    public int move(int y, int x){
        int newX = playerX+x;
        int newY = playerY+y;
        if(Map[newY][newX] != '0'){
            char tileInfo = Map[newY][newX];
            Map[playerY][playerX] = '.';
            Map[newY][newX]= '@';
            playerX = newX;
            playerY = newY;
            if(tileInfo == '1'){
                //enemy rat in tile
                return 21;
            }
            else if(tileInfo == '2'){
                //next enemy in tile 
                return 22;
            }
            else if(tileInfo == '3'){
                //next enemy in tile 
                return 23;
            }
            else if(tileInfo == '4'){
                //next enemy in tile 
                return 24;
            }
            else if(tileInfo == '5'){
                //next enemy in tile 
                return 25;
            }
            else{
                return 1;
            }
        }
        else{
            //player cannot move there
            return 0;
        }
        
        
        
        
        
        
        
    }
    
    public void readMap(){
        int x = 0;
        try{
            
            //create buff read with an instance of file read
            BufferedReader br = new BufferedReader(new FileReader("Map1.txt"));
            //read line
            String fileRead = br.readLine();
            while(fileRead != null){
		
		char[]temp = fileRead.toCharArray();
                for(int y=0; y<65; y++){
                    Map[x][y] = temp[y];
                }
		x++;		
		fileRead = br.readLine();
            }
            br.close();
        }
        catch(FileNotFoundException fnfe){
            System.out.println("file not found");
        }
        catch(IOException ioe){
            ioe.printStackTrace();
        }
    }
    
    
    
    
    
    
    
    
    
    
    class Tile{
        
        public Tile(){
            
        }
    }
    
    
    
}
