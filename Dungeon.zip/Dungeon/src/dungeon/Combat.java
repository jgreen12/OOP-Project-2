package dungeon;
/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */

/**
 *
 * @author Denny
 */
public class Combat {
    
    int viewNum;
    Dice dice;
        boolean level2 = false;
        boolean level3 = false;
        boolean level4 = false;
        boolean level5 = false;
        boolean level6 = false;
    int x;
    BaseCharacter player = new BaseCharacter(); //Change to whatever class the player chooses. 
    BaseCharacter enemy = new BaseCharacter();
    
    
    
    //added by Josh
    public Combat(int x){
        this.x = x;
        if(x == 1){
            player = new Warrior("Warrior");
        }
        if(x == 2){
            player = new Wizard("Wizard");
        }
        if(x == 3){
            player = new Thief("Thief");
        }
        dice = new Dice(x);
    }
    
    //edited by Josh 
    public void newEngagement(int enemyType)
    {
        if(enemyType == 1)
        {
            enemy = new EnemyRat();
        }
        else if(enemyType == 2)
        {
            enemy = new EnemySlime();
        }
        else if(enemyType == 3)
        {
            enemy = new EnemyTroll();
        }
        else if(enemyType == 4)
        {
            enemy = new EnemyGolem();
        }
        else if(enemyType == 5)
        {
            enemy = new EnemyDragon();
        }
    }
    
    public void levelUp()
    {
        
        if(player.exp > 15 && level2 == false)
        {
            player.levelUp();
            level2 = true;
        }
        else if(player.exp > 45 && level3 == false)
        {
            player.levelUp();
            level3 = true;
        }
        else if(player.exp > 90 && level4 == false)
        {
            player.levelUp();
            level4 = true;
        }
        else if(player.exp > 180 && level5 == false)
        {
            player.levelUp();
            level5 = true;
        }
        else if(player.exp > 360 && level6 == false)
        {
            player.levelUp();
            level6 = true;
        }
        else
        {            
        }
        
    }
    
    public boolean enemyDead()
    {
        if(enemy.currentHealth <= 0)
        {
            player.exp = player.exp + enemy.exp;
            levelUp();
            return true;
        }
        else
        {
            return false;
        }
    }
    
    boolean playerDead()
    {
        if(player.currentHealth <= 0)
        {
            return true;
        }
        else
        {
            return false;
        }
    }
    
    public String playerAttack()
    {
        String str;
        viewNum = dice.randomDiceAttack(player.mod);
        sy(player.type + " tries to hit: " + viewNum + " against "+ enemy.type + "'s AC: " + enemy.AC);
        str = player.type + " tries to hit: " + viewNum + " against "+ enemy.type + "'s AC: " + enemy.AC + ".\n";
        if(viewNum >= enemy.AC)
        {
            viewNum = dice.randomDiceDamagePlayer(player.equipedWeapon, player.mod);
            //player.currentHealth = player.currentHealth - viewNum;
            enemy.currentHealth = enemy.currentHealth-viewNum;
            sy("Enemy health at: "+enemy.currentHealth);
            str = str + "Enemy health at: "+enemy.currentHealth + ".\n";
            
        }  
        return str;
    }
    
    public void playerDefend()
    {
        player.AC = player.AC + 5;
        
    }
    public void playerUndefend(){
        player.AC = player.AC - 5;
    }
    
    public String Defense(){
        String str;
        
        
        playerDefend();
        str = "You've chosen to defend! Player AC now: " + player.AC + ".\n";
        str = str + enemyAttack();
        playerUndefend();
        
        return str;
    }
    
    
    public String enemyAttack()
    {
        String str;
        viewNum = dice.randomDiceAttack(enemy.mod);
        sy(enemy.type + " tries to hit: " + viewNum + " against "+ player.type + "'s AC: " + player.AC);
        str = enemy.type + " tries to hit: " + viewNum + " against "+ player.type + "'s AC: " + player.AC + ".\n";
        if(viewNum >= player.AC)
        {
            viewNum = dice.randomDiceDamagePlayer(enemy.equipedWeapon, enemy.mod);
            player.currentHealth = player.currentHealth - viewNum;
            
            str = str + "Player health at: " + player.currentHealth + ".\n";
        } 
        return str;
    }
    public void sy(String s)
    {
        System.out.println(s);
    }
    
}
