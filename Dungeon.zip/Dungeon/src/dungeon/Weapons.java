package dungeon;
/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */

/**
 *
 * @author Denny
 */
public class Weapons {
    
    
            //Warrior weapons
        int Club = 6;
        int longSwd = 8;
        int greatSwd = 10;
        
        //Thief weapons
        int dagger = 8;
        int shortSwd = 10;
        int Rapier = 12;
        
        
        //Wizard weapons
        int staff = 12;
        int greatStaff = 14;
        int grandStaff = 16;
        
        //Monster weapons
        int ratClaws = 4;
        int slimePounce = 6;
        int dragonClaws = 16;
        int trollClub = 10;
    
    public Weapons()
    {
    }
    
}
